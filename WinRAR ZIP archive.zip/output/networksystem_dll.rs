// Generated using https://github.com/a2x/cs2-dumper
// 2026-05-15 08:47:21.942553700 UTC

#![allow(non_upper_case_globals, non_camel_case_types, non_snake_case, unused)]

pub mod cs2_dumper {
    pub mod schemas {
        // Module: networksystem.dll
        // Class count: 1
        // Enum count: 0
        pub mod networksystem_dll {
            // Parent: None
            // Field count: 1
            pub mod ChangeAccessorFieldPathIndex_t {
                pub const m_Value: usize = 0x0; // int32
            }
        }
    }
}
